package parking;

import java.util.ArrayList;
import java.util.List;

public class Parking {
    private String type;
    private int capacity;
    private List<Car> data;

    public Parking(String type, int capacity) {
        this.type = type;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public void add(Car car) {
        if (capacity > data.size()) {
            data.add(car);
        }
    }

    public boolean remove(String manufacturer, String model) {
        for (Car item : data) {
            if (item.getManufacturer().equals(manufacturer) && item.getModel().equals(model)) {
                data.remove(item);
                return true;
            }
        }
        return false;
    }

    public Car getLatestCar() {
        Car oldestCar;
        if (data.isEmpty()) {
            return null;
        } else {
            oldestCar = null;
            int latestYear = 0;
            for (Car item : data) {
                if (item.getYear() > latestYear) {
                    latestYear = item.getYear();
                    oldestCar = item;
                }
            }
        }
        return oldestCar;
    }

    public Car getCar(String manufacturer, String model) {
        for (Car item : data) {
            if (item.getManufacturer().equals(manufacturer) && item.getModel().equals(model)) {
                return item;
            }
        }
        return null;
    }

    public int getCount() {
        return data.size();
    }

    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append("The cars are parked in " +  this.type + ":").append(System.lineSeparator());
        data.forEach(e -> sb.append(e.toString()).append(System.lineSeparator()));
        return sb.toString().trim();
    }
}
