package Jar;

public class Main {
    public static void main(String[] args) {
//        Jar<String> jar = new Jar<>();
//        jar.add("cookiesChoco");
//        jar.add("cookiesVanilla");
//        jar.add("cookiesCream");
//        String removed = jar.remove();
//        System.out.println(removed);
//        Jar<Integer> integerJar = new Jar<>();
//        integerJar.add(23);
//        integerJar.add(267);
//        integerJar.add(543);
//        integerJar.add(2);
//        int removedNum = integerJar.remove();
//        System.out.println(removedNum);
    }
}
