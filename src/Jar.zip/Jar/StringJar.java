package Jar;

public class StringJar extends Jar<String>{
    //inherits the fields
    //field stack -> ArrayDeque<String>

    //inherits the methods
    //add(String str)
    //String remove()-> returns String
}
